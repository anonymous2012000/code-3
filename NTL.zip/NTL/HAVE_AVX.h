#ifndef NTL_HAVE_AVX
#define NTL_HAVE_AVX
#endif

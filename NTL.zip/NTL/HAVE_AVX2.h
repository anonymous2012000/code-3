#ifndef NTL_HAVE_AVX2
#define NTL_HAVE_AVX2
#endif


#ifndef NTL_vec_vec_zz_p__H
#define NTL_vec_vec_zz_p__H

#include <NTL/vec_lzz_p.h>

NTL_OPEN_NNS

typedef Vec< Vec<zz_p> > vec_vec_zz_p;

NTL_CLOSE_NNS

#endif
